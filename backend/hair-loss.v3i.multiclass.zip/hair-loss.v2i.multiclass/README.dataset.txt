# hair-loss > 2024-06-17 3:31pm
https://universe.roboflow.com/uze/hair-loss-nq8hh

Provided by a Roboflow user
License: CC BY 4.0

