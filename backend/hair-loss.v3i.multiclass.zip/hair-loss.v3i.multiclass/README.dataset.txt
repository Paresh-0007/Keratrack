# hair-loss > 2024-06-19 5:02pm
https://universe.roboflow.com/uze/hair-loss-nq8hh

Provided by a Roboflow user
License: CC BY 4.0

